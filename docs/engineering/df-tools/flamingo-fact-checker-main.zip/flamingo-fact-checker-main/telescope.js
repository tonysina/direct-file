function createTelescope(container) {
  container.innerHTML = "";

  const heading = document.createElement("h3");
  heading.textContent = "Telescope";
  heading.style.margin = ".5em 0em";

  const factArea = document.createElement("div");
  factArea.id = "telescope-fact";
  factArea.style.minHeight = "30px";

  const breadcrumbs = document.createElement("div");
  breadcrumbs.id = "telescope-breadcrumbs";
  container.appendChild(heading);
  container.appendChild(factArea);
  container.appendChild(breadcrumbs);
}

function getCollectionInfo(path) {
  const uuidRegex =
    /#[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
  const matches = path.match(uuidRegex);
  if (!matches) {
    return { factName: path, uuid: null };
  }
  const uuid = matches[0];
  const factName = path.replace(uuidRegex, `*`);
  return { factName, uuid };
}

function telescopeEnable(enabled) {
  const telescope = document.getElementById("telescope-fact");
  if (telescope) {
    if (enabled) {
      const telescopeIcon = chrome.runtime.getURL("assets/eye-spark.svg");
      telescope.innerHTML = `Click on the eye icon <img src="${telescopeIcon}" width="16" height="16" alt="eye icon"> in the fact table to telescope into a fact.`;
    } else {
      telescope.innerHTML =
        "To enable the telescope feature, use environment variable <code>VITE_ENABLE_FLAMINGO_TELESCOPE</code> when running your frontend.";
    }
  }
}

function updateTelescopeFacts(factName, value, complete, icon) {
  const telescopeFacts = document.querySelectorAll(
    `#telescope .telescope-value`
  );
  telescopeFacts.forEach((telescopeItem) => {
    if (telescopeItem.dataset.fact === factName) {
      telescopeItem.innerHTML = "";
      telescopeItem.appendChild(icon.cloneNode());
      telescopeItem.appendChild(document.createTextNode(value));
      if (complete) {
        telescopeItem.classList.add("complete");
      } else {
        telescopeItem.classList.remove("complete");
      }
    }
  });
}

function telescopeFact(concretePath) {
  chrome.storage.local.get(["rawFacts"], (result) => {
    rawFacts = result.rawFacts;
    if (!rawFacts) {
      return;
    }
    const { factName, uuid } = getCollectionInfo(concretePath);
    const factData = rawFacts.find((f) => f[`@path`] == factName);
    const factIndex = rawFacts.findIndex((f) => f[`@path`] == factName);

    const telescope = document.getElementById("telescope-fact");
    telescope.dataset.factIndex = factIndex;
    telescope.innerHTML = factToHTML(concretePath, uuid, factData);

    telescope.querySelectorAll(".telescope-value").forEach((value) => {
      window.postMessage(
        { type: "CONTENT_REQ_FACT", factName: value.dataset.fact },
        "*"
      );
    });
    telescope.querySelectorAll(".telescope-link").forEach((link) => {
      link.addEventListener("click", handleTelescopeLink);
    });
    telescope.querySelectorAll("#telescope .tag-name").forEach((tag) => {
      tag.addEventListener("click", handleTelescopeTagClick);
    });
    telescope.querySelector(".telescope-track-btn").addEventListener("click", handleTelescopeTrack);
  });
}

function handleTelescopeTrack(event) {
  const fact = event.target.dataset.fact;
  addFactRow(fact, true);
  console.log("handleTelescopeTrack", event);
}

let breadcrumbs = [];
function updateBreadcrumbs(fact) {
  breadcrumbs.push(fact);
  if (breadcrumbs.length > 10) {
    breadcrumbs.shift();
  }
  const breadcrumbsContainer = document.getElementById("telescope-breadcrumbs");
  if (breadcrumbsContainer) {
    breadcrumbsContainer.innerHTML = breadcrumbs
      .map((path, index) => {
        const trFact = truncatedFact(path);
        const result = `<span class="breadcrumb"><a class="telescope-breadcrumb" data-index=${index} data-fact="${path}">${trFact}</a></span>`;
        return result;
      })
      .slice(-3)
      .join(" ▸ ");
  }
  document.querySelectorAll(".telescope-breadcrumb").forEach((link) => {
    link.addEventListener("click", handleBreadcrumbClick);
  });
}

function truncatedFact(fact) {
  return fact.replace(/^.+\//, "../");
}
// Called when a link in the fact definition is clicked
function handleTelescopeLink(event) {
  updateBreadcrumbs(event.target.dataset.fact);
  telescopeFact(event.target.dataset.fact);
}

// Called when the buttons in the fact table are clicked
function handleTelescopeFact(telescopeBtn) {
  const row = telescopeBtn.closest("tr");
  const concreteFactName = row.dataset.fact;
  breadcrumbs = [];
  updateBreadcrumbs(concreteFactName);
  telescopeFact(concreteFactName);
}

// Called when a breadcrumb link in clicked
function handleBreadcrumbClick(event) {
  const index = event.target.dataset.index;
  breadcrumbs = breadcrumbs.slice(0, index);
  updateBreadcrumbs(event.target.dataset.fact);
  telescopeFact(event.target.dataset.fact);
}

function handleTelescopeTagClick(event) {
  const selected = event.target.parentElement.classList.contains("selected");
  document.querySelectorAll("#telescope .tag-name").forEach((tag) => {
    tag.parentElement.classList.remove("selected");
  });
  if (!selected) {
    event.target.parentElement.classList.add("selected");
  } else {
    event.target.parentElement.classList.remove("selected");
  }
}

// Construct a path from the parent factname and a relative path
function constructPath(factName, uuid, relativePath) {
  let basePath = factName.replace(/\/[^/]+$/, "");
  let factPath = relativePath.replace("..", basePath);
  if (uuid) {
    return factPath.replace("*", uuid);
  }
  return factPath;
}

function createXmlTag(tag, attrs, contents, factName, uuid) {
  const parsedAttrs = attrs
    .map(([key, value]) => {
      const attr = key.startsWith("@") ? key.replace(/^@/, "") : key;
      let factVal = ``;

      if (attr === `path`) {
        const originalPath = value;
        const path = constructPath(factName, uuid, originalPath);
        factVal = `<span class="telescope-value" data-fact="${path}"></span>`;
        value = `<a class="telescope-link" data-fact="${path}">${originalPath}</a>`;
      }
      return ` ${attr}="${value}"${factVal}`;
    })
    .join(``);

  const noEmbed = new Set(["Filter", "CollectionSum"]).has(tag);
  const htmlTag = `<span class="tag-name">${tag}</span>`;
  const containerTag = `<div class="tag-container ${
    noEmbed ? `no-embed` : ``
  }">`;
  if (contents === ``) {
    return `${containerTag}&lt;${htmlTag}${parsedAttrs}/&gt;</div>`;
  } else {
    return `${containerTag}&lt;${htmlTag}${parsedAttrs}&gt;${contents}&lt;${htmlTag}&gt;</div>`;
  }
}

function recurseFactTree(factName, uuid, obj) {
  const metas = Object.entries(obj).map(([tag, contents]) => {
    if (tag.startsWith("@")) {
      return ``;
    } else if (Array.isArray(contents)) {
      const entries = contents.map((arrayEntry) => {
        const refac = { [tag]: arrayEntry };
        return recurseFactTree(factName, uuid, refac);
      });
      return entries.join("");
    } else if (typeof contents === `object`) {
      // attributes are stored as @ values
      const attrs = Object.entries(contents).filter(([key, value]) =>
        key.startsWith("@")
      );
      // Get facts from path attributes
      attrs.forEach(([key, value]) => {
        if (key === `@path`) {
          factVal = `<span id="fp-${value}" />`;
        }
      });
      // Construct the subtree
      const parsedContent = recurseFactTree(factName, uuid, contents);
      return createXmlTag(tag, attrs, parsedContent, factName, uuid);
    } else {
      return createXmlTag(tag, [], contents, factName, uuid);
    }
  });
  return metas.join("");
}

function factToHTML(concretePath, uuid, factDefinition) {
  // Get the name and description of the fact out
  const {
    Name: name = "",
    Description: description,
    "@path": abstractPath,
    srcFile,
    ...factData
  } = factDefinition;

  const persistIcon = chrome.runtime.getURL(
    "assets/square-rounded-plus.svg"
  );


  let htmlContent = `<div class="info">Path: <strong>${concretePath}</strong>`;
  htmlContent += `<button class="usa-button usa-button--unstyled">`;
  htmlContent += `<img class="telescope-track-btn" src="${persistIcon}" title="Monitor fact" data-fact="${concretePath}" alt="monitor"></button><br>`;
  htmlContent += `Value:<span class="telescope-value" data-fact="${concretePath}"></span></strong><br>`;
  htmlContent += `Description: ${description}<br>Module: ${srcFile}<br></div>`;

  const result = recurseFactTree(concretePath, uuid, factData);
  htmlContent += `<div class="define">${result}</div>`;

  return htmlContent;
}

// For testing export the functions
if (typeof module !== "undefined") {
  module.exports = {
    telescopeFact,
    updateBreadcrumbs,
    handleTelescopeTagClick,
    handleTelescopeLink,
    handleBreadcrumbClick,
    handleTelescopeFact,
    createXmlTag,
  };
}
