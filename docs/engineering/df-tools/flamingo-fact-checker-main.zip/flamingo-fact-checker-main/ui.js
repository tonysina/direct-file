// Inject the UI into the page (e.g., the table above the footer)
function injectUI() {
  const container = document.createElement("div");
  container.id = "flamingo-container";
  container.classList.add("grid-container", "screen");

  const factTracker = document.createElement("div");
  factTracker.id = "fact-tracker";
  factTracker.classList.add("flamingo-section");
  createTracker(factTracker);

  const endSpacer = document.createElement("div");
  endSpacer.id = "end-spacer";
  endSpacer.style.height = "8px";

  const rewind = document.createElement("div");
  rewind.id = "rewind";
  rewind.classList.add("flamingo-section");
  createRewind(rewind);

  const hotLinks = document.createElement("div");
  hotLinks.id = "fact-monitor";
  hotLinks.classList.add("flamingo-section");
  createHotLinks(hotLinks);

  const telescope = document.createElement("div");
  telescope.id = "telescope";
  telescope.classList.add("flamingo-section");
  createTelescope(telescope);

  container.style.position = "relative";
  const flamingoFooter = document.createElement("div");
  flamingoFooter.id = "flamingo-footer";
  flamingoFooter.classList.add("flamingo-banner");

  const flamingoHeader = document.createElement("div");
  flamingoHeader.id = "flamingo-header";
  flamingoHeader.classList.add("flamingo-banner");
  flamingoHeader.textContent = "FLAMINGO FACT CHECKER";


  container.appendChild(flamingoHeader);
  container.appendChild(factTracker);
  container.appendChild(document.createElement("hr"));
  container.appendChild(telescope);
  container.appendChild(document.createElement("hr"));
  container.appendChild(rewind);
  container.appendChild(document.createElement("hr"));
  container.appendChild(hotLinks);
  container.appendChild(endSpacer);
  container.appendChild(flamingoFooter);

  const mainContent = document.querySelector(".main-content-wrapper");

  if (mainContent) {
    mainContent.appendChild(container);
  }

  return container;
}

function emptyTempTable() {
  const formFactsTable = document.getElementById("form-facts");
  if (formFactsTable) {
    formFactsTable.innerHTML = "";
  }
}

function createRewind(container) {
  container.innerHTML = "";

  const heading = document.createElement("h3");
  heading.textContent = "Rewind";

  const historySelect = document.createElement("select");
  historySelect.id = "history-select";
  historySelect.style.width = "100%";
  historySelect.classList.add("usa-select");
  historySelect.style.marginBottom = "0.5rem";

  const rewindButton = document.createElement("button");
  rewindButton.textContent = "Rewind";
  rewindButton.classList.add("usa-button");

  const clearButton = document.createElement("button");
  clearButton.textContent = "Clear";
  clearButton.classList.add("usa-button", "usa-button--outline");

  container.appendChild(heading);
  container.appendChild(historySelect);
  container.appendChild(rewindButton);
  container.appendChild(clearButton);

  const handleRewind = () => {
    const selectedIndex = historySelect.value;
    if (selectedIndex !== "") {
      rewindTo(parseInt(selectedIndex));
    }
  };
  rewindButton.addEventListener("click", handleRewind);

  clearButton.addEventListener("click", () => {
    clearHistory();
  });

  historySelect.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      handleRewind();
    }
  });
}

function createHistory(history) {
  const historySelect = document.getElementById("history-select");
  if (historySelect) {
    historySelect.innerHTML = "";

    const defaultOption = document.createElement("option");
    defaultOption.value = "";
    defaultOption.textContent = "Select a history entry";
    historySelect.appendChild(defaultOption);

    // Construct the dropdown options
    const dropOptions = [];
    history.forEach((entry, index) => {
      const date = new Date(entry.timestamp);
      const localDate = new Date(entry.timestamp);
      const format = {
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
      };

      const formattedDate = new Intl.DateTimeFormat("en-US", format)
        .format(date)
        .replace(",", "");
      const url = entry.url.replace(/^.*df\/file\//, "");

      dropOptions[index] = {
        value: index,
        url: url,
        content: `${formattedDate} ${url}`,
      };
    });

    // Add the dropdown options to the UI
    dropOptions.reverse().forEach((entry) => {
      const option = document.createElement("option");
      option.value = entry.value;
      option.textContent = entry.content;
      historySelect.appendChild(option);
    });
  }
}

function createTracker(container) {

  const heading = document.createElement("h3");
  heading.textContent = "Fact Tracker";

  // Add table, buttons, etc.
  const table = document.createElement("table");
  table.id = "facts-table";
  table.classList.add("usa-table", "usa-table--borderless", "font-body-2xs");
  table.innerHTML = `
    <thead>
      <tr><th>Fact</th><th>Value</th><th>Actions</th></tr>
    </thead>
    <tbody id="track-facts"></tbody>
    <tbody class="form-tbody">
      <tr><th>Facts from this page</th><th>Value</th><th>Actions</th></tr>
    </tbody>
    <tbody id="form-facts" class="form-tbody"></tbody>
  `;

  const addButton = document.createElement("button");
  addButton.textContent = "Add Fact";
  addButton.classList.add("button", "usa-button");
  addButton.onclick = addFact;

  const clearButton = document.createElement("button");
  clearButton.textContent = "Clear Tracked";
  clearButton.classList.add("button", "usa-button", "usa-button--outline");
  clearButton.onclick = () => clearFacts("TRACKED");

  const clearErrorsButton = document.createElement("button");
  clearErrorsButton.textContent = "Clear Errors";
  clearErrorsButton.classList.add("button", "usa-button", "usa-button--outline");
  clearErrorsButton.onclick = () => clearFacts("ERROR");

  const refreshButton = document.createElement("button");
  refreshButton.id = "refresh-button";
  refreshButton.textContent = "Refresh";
  refreshButton.classList.add("button", "usa-button", "usa-button--outline");
  refreshButton.onclick = refreshValues;

  const factInput = document.createElement("input");
  factInput.type = "text";
  factInput.placeholder = "Enter factname as /factname";
  factInput.id = "fact-input";
  factInput.classList.add("usa-input");
  factInput.setAttribute("list", "fact-suggestions");
  factInput.autocomplete = "off";

  const factSuggestions = document.createElement("datalist");
  factSuggestions.id = "fact-suggestions";

  const collectionIdInput = document.createElement("input");
  collectionIdInput.type = "text";
  collectionIdInput.placeholder = "Enter collection id as #uuid";
  collectionIdInput.id = "collection-id-input";
  collectionIdInput.autocomplete = "off";
  collectionIdInput.classList.add("usa-input");
  collectionIdInput.setAttribute("list", "collection-id-suggestions");

  const collectionIdSuggestions = document.createElement("datalist");
  collectionIdSuggestions.id = "collection-id-suggestions";

  container.appendChild(heading);
  container.appendChild(table);
  container.appendChild(addButton);
  container.appendChild(clearButton);
  container.appendChild(clearErrorsButton);
  container.appendChild(refreshButton);
  container.appendChild(factInput);
  container.appendChild(factSuggestions);
  container.appendChild(collectionIdInput);
  container.appendChild(collectionIdSuggestions);
}

function createHotLinks(container) {
  container.innerHTML = "<h3>Hot Links</h3>";
  const hotLinkSelect = document.createElement("select");
  hotLinkSelect.id = "hotlink-select";
  hotLinkSelect.classList.add("usa-select");

  container.appendChild(hotLinkSelect);
}
function parsePageUrl() {
  const fullUrl = window.location.href;
  const matches = fullUrl.match(/^(.*\/df\/file\/)(.*)$/);
  return matches;
}

function populateHotLinks(factGraph) {
  const hotLinkSelect = document.getElementById("hotlink-select");
  if (!hotLinkSelect) {
    return;
  }
  hotLinkSelect.innerHTML = "";

  const getFullName = (fact) => {
    const firstName = factGraph[`${fact}/firstName`]?.item;
    const lastName = factGraph[`${fact}/lastName`]?.item;
    const fullName = `${firstName || ""} ${lastName || ""}`.trim();
    return fullName;
  };

  const cleanCollectionName = (collectionName) => {
    collectionName = collectionName.replace(/^\//, "");
    collectionName = collectionName.replace(/s$/, "");
    collectionName =
      collectionName.charAt(0).toUpperCase() + collectionName.slice(1);
    return collectionName;
  };

  const getLink = (collectionName, itemId, baseUrl) => {
    const itemName = `${collectionName}/#${itemId}`;
    const dataviewLink = `${baseUrl}data-view/loop/${encodeURIComponent(
      collectionName
    )}/${itemId}`;
    let prettyName = itemName;

    // Get full name if possible
    const fullName = getFullName(`${collectionName}/#${itemId}`);

    // If filers, unique link for about you and spouse
    let link = "";
    if (collectionName === "/filers") {
      const isPrimary = factGraph[`${itemName}/isPrimaryFiler`]?.item;
      if (isPrimary) {
        link = `${baseUrl}data-view/flow/you-and-your-family/about-you?${encodeURIComponent(
          `/primaryFiler`
        )}=${itemId}`;
        prettyName = `Filer ${fullName}`;
      } else {
        link = `${baseUrl}data-view/flow/you-and-your-family/spouse?${encodeURIComponent(
          `/secondaryFiler`
        )}=${itemId}`;
        prettyName = fullName === `` ?  `Undefined Spouse`: `Spouse ${fullName}`;
      }
      return { itemName, prettyName, link };
    }

    // Dependents, just use default dataview link
    if (fullName) {
      return { itemName, prettyName: `Family member ${fullName}`, link: dataviewLink };
    }

    // Try to get filer
    const filerId = factGraph[`${collectionName}/#${itemId}/filer`]?.item.id;
    if (filerId) {
      const filerFullName = getFullName(`/filers/#${filerId}`);
      if (filerFullName) {
        prettyName = `${cleanCollectionName(
          collectionName
        )} for ${filerFullName}`;
        return { itemName, prettyName, link: dataviewLink };
      }
    }

    return { itemName, prettyName, link: dataviewLink };
  };
  const [, baseUrl] = parsePageUrl();

  const collections = Object.entries(factGraph)
    .filter(
      ([key, value]) =>
        value["$type"] == "gov.irs.factgraph.persisters.CollectionWrapper"
    )
    .reverse()
    .flatMap((collection) => {
      // Some collections could have multiple paths, unfortunately 
      // there's no way to tell what the url would be from fg so hardcoded.
      let collectionNames = [collection[0]]
      if (collection[0] === '/cdccCareProviders') {
        collectionNames = ['benefits-care-providers', 'cdcc-care-providers']
      }
      return collectionNames.map(collectionName => {
        return collection[1].item.items.map((item) =>
          getLink(collectionName, item, baseUrl)
        );
      }).flat();
    });

  const defaultOption = document.createElement("option");
  defaultOption.value = "";
  defaultOption.textContent = "Hotlink to a collection item";
  hotLinkSelect.appendChild(defaultOption);

  collections.forEach((collection) => {
    const option = document.createElement("option");
    option.value = collection.link;
    option.textContent = collection.prettyName;
    hotLinkSelect.appendChild(option);
  });
}
