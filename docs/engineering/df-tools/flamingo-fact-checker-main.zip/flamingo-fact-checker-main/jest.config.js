module.exports = {
  testEnvironment: 'node',
  transform: {},
  testMatch: ['**/*.test.js'],
  setupFiles:  ['<rootDir>/telescope.js']
}; 
