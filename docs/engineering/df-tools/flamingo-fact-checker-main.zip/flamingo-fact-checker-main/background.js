

chrome.runtime.onInstalled.addListener((details) => {
  if(details.reason !== "install" && details.reason !== "update") return;

  // on install load any older isDebug state
  chrome.storage.local.get("isDebug", (data) => {
    isDebug = data.isDebug || false;
    const toggleDebugMenuId = chrome.contextMenus.create({
      id: "toggle-debug",
      title: "Debug Logs",
    contexts: ["action"],
    checked: isDebug,
    type: "checkbox"
    });
    // store the state and id
    chrome.storage.local.set({ isDebug, toggleDebugMenuId });
  });
});


function contextClick(info, tab) {
  const { menuItemId } = info;
  chrome.storage.local.get("isDebug", (data) => {
    isDebug = data.isDebug || false;
    isDebug = !isDebug;
    // chrome.tabs.sendMessage(tab.id, { action: "LOG_MESSAGE", source: "BG", message: `BG: Request isDebug to ${isDebug}` });

    chrome.tabs.sendMessage(tab.id, { action: "BG_TOGGLE_DEBUG", isDebug });
    
    chrome.contextMenus.update(menuItemId, { checked: isDebug });
    chrome.storage.local.set({ isDebug });
  });
}
chrome.contextMenus.onClicked.addListener(contextClick);
