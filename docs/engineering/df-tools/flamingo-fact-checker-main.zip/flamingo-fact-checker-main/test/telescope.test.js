// Import necessary modules for testing
const { JSDOM } = require("jsdom");

// Mock the chrome functions
global.chrome = {
  runtime: {
    getURL: (path) => `chrome-extension://mocked/${path}`,
    onMessage: {
      addListener: jest.fn(),
    },
  },
  storage: {
    local: {
      get: jest.fn(),
      set: jest.fn(),
    },
  },
};

// Mock the window functions
global.window = {
  postMessage: jest.fn(),
  addEventListener: jest.fn(),
};

const { telescopeFact, createXmlTag } = require("../telescope.js");

describe("telescopeFact", () => {
  // Mock setup
  beforeEach(() => {
    // Mock DOM elements and methods
    const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>");
    global.document = dom.window.document;
    document.body.innerHTML = `
        <div id="telescope-fact"></div>
        <div id="telescope"></div>
      `;
  });

  it("should properly process a fact and update the telescope view", () => {
    // Mock raw facts data
    const mockRawFacts = [
      { "@path": "other/fact", name: "Other Fact" },
      {
        Description: "Whether Form 2441 should be submitted",
        Export: {
          "@mef": "true",
        },
        Derived: {
          Any: {
            Dependency: [
              {
                "@path": "/isReceivingCdccCredit",
              },
            ],
          },
        },
        "@path": "/test/fact/path",
        srcFile: "cdcc.xml",
      },
    ];

    // Setup chrome storage mock to return our test data
    chrome.storage.local.get.mockImplementation((keys, callback) => {
      callback({ rawFacts: mockRawFacts });
    });

    // Call the function
    telescopeFact("/test/fact/path");

    // Verify chrome storage was called correctly
    expect(chrome.storage.local.get).toHaveBeenCalledWith(
      ["rawFacts"],
      expect.any(Function)
    );

    // Verify telescope element was updated
    const telescopeElement = document.getElementById("telescope-fact");
    expect(telescopeElement.dataset.factIndex).toBe("1");
    const selector =
      ".define > .tag-container > .tag-container > .tag-container > .telescope-link";
    const dependency = telescopeElement.querySelector(selector);
    expect(dependency.innerHTML).toBe("/isReceivingCdccCredit");

    // Verify window.postMessage was called for the facts
    expect(window.postMessage.mock.calls).toEqual([
      [{ type: "CONTENT_REQ_FACT", factName: "/test/fact/path" }, "*"],
      [{ type: "CONTENT_REQ_FACT", factName: "/isReceivingCdccCredit" }, "*"],
    ]);
  });
});

describe("createXmlTag", () => {
  test("creates self-closing tag when no contents provided", () => {
    const tag = "Dependency";
    const attrs = [["@path", "../anotherFact"]];
    const contents = "";
    const uuid = `#eaf0e006-f79e-4a8b-a9a0-ab64dea947cb`;
    const factName = "/filers/*/fact";

    const result = createXmlTag(tag, attrs, contents, factName, uuid);

    expect(result).toBe(
      `<div class="tag-container ">` +
        `&lt;<span class="tag-name">Dependency</span>` +
        ` path="<a class="telescope-link" data-fact="/filers/${uuid}/anotherFact">../anotherFact</a>"` +
        `<span class="telescope-value" data-fact="/filers/${uuid}/anotherFact"></span>/&gt;` +
        `</div>`
    );
  });

  test("creates opening and closing tags when contents provided", () => {
    const tag = "Add";
    const attrs = [["@type", "test"]];
    const contents = "<some>content</some>";
    const factName = "/test/fact";
    const uuid = null;

    const result = createXmlTag(tag, attrs, contents, factName, uuid);

    expect(result).toBe(
      '<div class="tag-container ">' +
        '&lt;<span class="tag-name">Add</span>' +
        ' type="test"' +
        "&gt;<some>content</some>&lt;" +
        '<span class="tag-name">Add</span>&gt;' +
        "</div>"
    );
  });

  test("creates no-embed paths", () => {
    const tag = "Filter";
    const attrs = [["@type", "test"]];
    const contents = "<some>content</some>";
    const factName = "/test/fact";
    const uuid = null;

    const result = createXmlTag(tag, attrs, contents, factName, uuid);

    expect(result).toBe(
      '<div class="tag-container no-embed">' +
        '&lt;<span class="tag-name">Filter</span>' +
        ' type="test"' +
        "&gt;<some>content</some>&lt;" +
        '<span class="tag-name">Filter</span>&gt;' +
        "</div>"
    );
  });

  test("handles uuid replacement in paths", () => {
    const tag = "Test";
    const attrs = [["@path", "../anotherFact"]];
    const contents = "";
    const factName = "/parent/*/someFact";
    const uuid = "#123e4567-e89b-12d3-a456-426614174000";

    const result = createXmlTag(tag, attrs, contents, factName, uuid);

    expect(result).toBe(
      `<div class="tag-container ">` +
        `&lt;<span class="tag-name">Test</span>` +
        ` path="<a class="telescope-link" data-fact="/parent/${uuid}/anotherFact">../anotherFact</a>"` +
        `<span class="telescope-value" data-fact="/parent/${uuid}/anotherFact"></span>/&gt;` +
        `</div>`
    );
  });
});
