(function () {
  var debug = function () {};
  // var debug = console.log.bind(window.console)

  // Listen for URL changes
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      const factGraph = debugFactGraph.toJSON();
      addFormFacts();
      window.postMessage({ type: "PAGE_FACT_GRAPH", factGraph, url }, "*");
    }
  }).observe(document, { subtree: true, childList: true });

  // Listen for messages from the content script
  window.addEventListener("message", function (event) {
    if (event.source !== window) return;

    if (event.data.type === "CONTENT_REQ_FACT") {
      debug("PS: Received message", event.data.type, event.data);
      const factName = event.data.factName;
      requestFactValue(factName);

    } else if (event.data.type === "CONTENT_REQ_DICT") {
      debug("PS: Received message", event.data.type, event.data);
      debug("PS: Sending PAGE_FACT_DICT for dict");
      window.postMessage({ type: "PAGE_FACT_DICT", debugFacts }, "*");

    } else if (event.data.type === "TOGGLE_DEBUG_PAGE_XX") {
      debug(
        "PS: Received TOGGLE_DEBUG_PAGE",
        event.data.isDebug ? "on" : "off"
      );
      if (event.data.isDebug) {
        debug = debug.bind(window.console);
      } else {
        debug = function () {};
      }

    } else if (event.data.type === "CONTENT_REQ_FACTGRAPH") {
      debug("PS: Received message", event.data.type, event.data);
      debug("Received message CONTENT_REQ_FACTGRAPH", event.data.factGraph);
      let factJson = JSON.parse(event.data.factGraph);
      factJson = factJson.facts ? factJson.facts : factJson;
      loadFactGraph(factJson);
      if (event.data.url) {
        window.location.href = event.data.url;
      }
    }
  });

  // Create and inject the input and datalist elements
  const factInput = document.getElementById("fact-input");
  const collectionIdInput = document.getElementById("collection-id-input");
  const collectionIdSuggestions = document.getElementById(
    "collection-id-suggestions"
  );

  function requestFactValue(factName) {
    let complete, value;

    // Check if fact exists and get complete status
    try {
      complete = debugFactGraph.get(factName).complete;
    } catch (e) {
      debug("No such fact", factName);
      const data = {
        type: "PAGE_FACT_VALUE",
        factName,
        complete: false,
        value: null,
        status: "FAIL",
      };
      debug("PS: Sending PAGE_FACT_VALUE ", data);
      window.postMessage(data, "*");
      return;
    }

    // Get the value of the fact (placeholder or otherwise)
    try {
      value = debugFactGraph.get(factName).get.toString();
      // Send the value back to the content script
      const data = {
        type: "PAGE_FACT_VALUE",
        factName,
        complete,
        value,
        status: "SUCCESS",
      };
      debug("PS: Sending PAGE_FACT_VALUE ", data);
      window.postMessage(data, "*");
    } catch (e) {
      // Not an error, there was no placeholder
      const data = {
        type: "PAGE_FACT_VALUE",
        factName,
        complete,
        value: null,
        status: "SUCCESS",
      };
      debug("PS: Sending PAGE_FACT_VALUE ", data);
      window.postMessage(data, "*");
    }
  }

  const updateCollectionAutocomplete = (input, collection, datalist) => {
    // CAN ONLY BE RUN ON PAGE SIDE
    const writFacts = debugFactGraph.toStringDictionary();
    const uuids = Object.keys(writFacts)
      .filter((factPath) => factPath.startsWith(collection))
      .map((fact) => {
        const uuidMatch = fact.match(
          /(#[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i
        );
        if (uuidMatch) {
          return uuidMatch[1];
        }
        return null;
      })
      .filter((uuid) => uuid !== null);
    const uniqueUuids = [...new Set(uuids)];

    // Update the datalist
    datalist.innerHTML = "";
    // debug("uniqueUuids", uniqueUuids)
    uniqueUuids.forEach((name) => {
      const option = document.createElement("option");
      option.value = name;
      datalist.appendChild(option);
    });
  };

  // Collection ID Input Event Listeners
  if (collectionIdInput) {
    collectionIdInput.addEventListener("focus", function () {
      const collection = factInput.value.split("*")[0];
      updateCollectionAutocomplete(this, collection, collectionIdSuggestions);
    });

    collectionIdInput.addEventListener("keydown", function (event) {
      if (event.key === "Enter") {
        let factName = factInput.value;
        if (collectionIdInput.value) {
          factName = factName.replace("*", collectionIdInput.value);
        }
        const data = {
          type: "PAGE_ADD_FACT",
          factName: factName,
          persist: true,
        };
        debug("PS: Sending PAGE_ADD_FACT", data);
        window.postMessage(data, "*");
        factInput.focus();
      }
    });
  }

  const addFormFacts = () => {
    window.postMessage({ type: "PAGE_CLEAR_FACTS", which: "TEMP" }, "*");
    const location = window.location.href;

    const sendRequest = (factName) => {
      const data = {
        type: "PAGE_ADD_FACT",
        factName: factName,
        persist: false,
      };
      debug("PS: Sending PAGE_ADD_FACT", data);
      window.postMessage(data, "*");
    };
    let matches = document.querySelectorAll("#the_form fieldset");
    matches.forEach((fieldset) => {
      const factName = fieldset.id.replace(/^id-/, "");
      sendRequest(factName);
    });
    matches = document.querySelectorAll("#the_form .usa-input-group > input");
    matches.forEach((input) => {
      const factName = input.id.replace(/^id-/, "");
      sendRequest(factName);
    });
    // match input masked fields
    matches = document.querySelectorAll(
      "#the_form .usa-form-group > .usa-input-mask > input"
    );
    matches.forEach((input) => {
      const factName = input.id.replace(/^id-/, "");
      sendRequest(factName);
    });
    matches = document.querySelectorAll("#the_form .usa-form-group > select");
    matches.forEach((input) => {
      const factName = input.id.replace(/^id-/, "");
      sendRequest(factName);
    });
  };

  let fgRetries = 5;
  let fgDone = false;
  function initPage() {
    try {
      const url = window.location.href;
      // Don't run on logout page
      if (url.includes("auth/logout")) {
        return;
      }
      debugFactGraph;
      debug("debugFactGraph loaded.");
      const factGraph = debugFactGraph.toJSON();
      window.postMessage({ type: "PAGE_FACT_GRAPH", factGraph, url }, "*");
      
      addFormFacts();
      initRawFacts();
    } catch (error) {
      if (fgRetries > 0) {
        fgRetries--;
        setTimeout(initPage, 500);
        return;
      } else {
        debug("Error accessing debugFactGraph, giving up.");
      }
    }
  }

  let rfRetries = 5;
  function initRawFacts() {
    try {
      rawFacts;
      debug("Raw facts loaded.");
      window.postMessage({ type: "PAGE_RAW_FACTS", rawFacts }, "*");
      window.postMessage({ type: "PAGE_SCRIPT_READY" }, "*");

    } catch (error) {
      if (rfRetries > 0) {
        rfRetries--;
        setTimeout(initRawFacts, 500);
        return;
      } else {
        debug("Error accessing rawFacts, giving up.");
        window.postMessage({ type: "PAGE_RAW_FACTS" }, "*");
        window.postMessage({ type: "PAGE_SCRIPT_READY" }, "*");
      }
    }
  }

  initPage();
})();
