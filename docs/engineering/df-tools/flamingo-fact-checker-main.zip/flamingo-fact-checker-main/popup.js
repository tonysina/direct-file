const factsArea = document.getElementById("facts-area");
chrome.storage.local.get("trackedFacts", (data) => {
  if (data.trackedFacts) {
    factsArea.textContent = data.trackedFacts.join("\n");
  }
});

// Track facts buttons
document.getElementById("load-facts").addEventListener("click", () => {
  const factsArea = document.getElementById("facts-area");
  if (factsArea) {
    const facts = factsArea.value.split("\n").filter(Boolean);
    chrome.storage.local.set({ trackedFacts: facts }, () => {});
    // Send message to content script to refresh values
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (tabs[0]) {
        chrome.tabs.sendMessage(
          tabs[0].id,
          { action: "refreshValues" },
          function (response) {
            if (chrome.runtime.lastError) {
              messageStatus("Something went wrong :(");
            } else {
              messageStatus("Facts loaded to tracker.", true);
            }
          }
        );
      }
    });
  }
});

document.getElementById("copy-facts").addEventListener("click", () => {
  const factsArea = document.getElementById("facts-area");
  navigator.clipboard.writeText(factsArea.value);
});

// FACTGRAPH
const factgraphArea = document.getElementById("factgraph-area");
// chrome.storage.local.get(function(result){console.log(result)})

chrome.storage.local.get(["factGraph"], (data) => {
  if (data.factGraph) {
    factgraphArea.value = JSON.stringify(data.factGraph);
    messageStatus(`Init ${Object.keys(data.factGraph).length} facts.`);
  }
});

// FactGraph buttons
document.getElementById("copy-factgraph").addEventListener("click", () => {
  const factgraphArea = document.getElementById("factgraph-area");
  messageStatus(
    `Copied ${
      Object.keys(JSON.parse(factgraphArea.value)).length
    } facts in factgraph.`,
    true
  );
  navigator.clipboard.writeText(factgraphArea.value);
});

document.getElementById("load-factgraph").addEventListener("click", () => {
  const factgraphArea = document.getElementById("factgraph-area");
  if (factgraphArea) {
    const factgraphToLoad = factgraphArea.value;
    let factJson;
    try {
      factJson = JSON.parse(factgraphToLoad);
    } catch (e) {
      messageStatus(`Not a valid factgraph. Could not parse.`, true);
      return;
    }
    factJson = factJson.facts ? factJson.facts : factJson;
    if (!factJson["/filers"]) {
      messageStatus(`Not a valid factgraph. No filers found.`, true);
      return;
    }

    const objString = '{key1: "value1", key2: 2}';
    const jsonString = objString.replace(/([a-zA-Z0-9_-]+):/g, '"$1":');
    console.log(JSON.parse(jsonString)); // Output: { "key1": "value1", "key2": 2 }

    // Send message to content script to load factgraph
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (tabs[0]) {
        chrome.tabs.sendMessage(
          tabs[0].id,
          { action: "PP_LOAD_FACT_GRAPH", factgraph: factgraphToLoad },
          function (response) {
            if (chrome.runtime.lastError) {
              messageStatus("Something went wrong :(");
            } else {
              messageStatus(
                `Loaded ${Object.keys(factJson).length} facts in factgraph.`,
                true
              );
            }
          }
        );
      }
    });
  }
});

function messageStatus(message, timeout = false) {
  const statusArea = document.getElementById("status-area");

  statusArea.textContent = message;
  if (timeout) {
    setTimeout(function () {
      statusArea.textContent = "";
    }, 3000);
  }
}
